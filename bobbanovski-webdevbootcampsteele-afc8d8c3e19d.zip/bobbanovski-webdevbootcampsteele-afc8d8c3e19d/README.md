# README #

This README would normally document whatever steps are necessary to get your application up and running.

This repository is a collection of all exercises from the WebDeveloper Bootcamp on Udemy:
https://www.udemy.com/the-web-developer-bootcamp/

### How do I get set up? ###

Currently the project consists of html files and dependent files, such as images, css and js sheets.
Downloading the files to the one folder and running the desired html file should be sufficient to run the file
* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner: Robert
* Other community or team contact